// File cấu hình chung cho cả dự án
plugins {
    // Khai báo phiên bản 8.1.0 cho Plugin Android (Tương thích Gradle 8.0)
    id("com.android.application") version "8.1.0" apply false
}